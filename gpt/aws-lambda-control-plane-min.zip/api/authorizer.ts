export const handler = async () => {
  return { isAuthorized: true };
};